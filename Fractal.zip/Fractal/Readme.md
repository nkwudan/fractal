
# MQTT Alarm Aggregator

My submission of an MQTT client that subscribes and keeps track of six alarm topics using Node.js.

## Setup
To get the project setup with dependencies and required modules, start off by running:

```bash
  npm install
```

## Running Tests

To run tests, run the following command from the root of the project

```bash
  npm test
```

This command will execute unit and integration tests stored in the tests folder in Jest
## Usage/Examples

To run this application with mosquito, follow the instructions below:

Install mosquito

```bash
brew Install mosquitto
```

Start the mqtt service

```bash
brew services start mosquitto
```

Publish messages to the topics with the following format

```bash
mosquitto_pub -t {{topic}} -m {{message}} -r
```
## Authors

- Nkwuda Lynda Nwankwo

