const aedes = require('aedes')();
const server = require('net').createServer(aedes.handle);
const mqtt = require('mqtt');
const { connectAndSubscribe } = require('../src/helpers');
let testTopic = "test/status"

// INTEGRATION TEST :: Testing the connection and abilitity to subscribe and publish to MQTT
describe('MQTT Client Integration', () => {
  let client;
  const port = 1884; // Using a different port to avoid conflicts

  beforeAll((done) => {
    server.listen(port, () => {
      client = mqtt.connect(`mqtt://localhost:${port}`);
      connectAndSubscribe(client);
      done();
    });
  });

  afterAll((done) => {
    client.end(true, () => { // Ensure the client disconnects cleanly
      server.close(() => { // Close the server
        aedes.close(() => { // Ensure the aedes broker shuts down
          done();
        });
      });
    });
  });

  it('subscribes and handles messages correctly', (done) => {
    const testMessage = '1';

    client.on('connect', () => {
      client.subscribe(testTopic, () => {
        aedes.publish({ topic: testTopic, payload: testMessage });
      });
    });

    client.on('message', (topic, message) => {
      expect(topic).toBe(testTopic);
      expect(message.toString()).toBe(testMessage);
      done();
    });
  });
});
