const { updateLastState } = require('../src/helpers');
const topics = require('../src/topics.json');
let topic = topics.childTopics[0];

// UNIT TEST :: Testing an update to the last known state of a topic
describe('updateLastState', () => {
  it('updates the state correctly', () => {
    const state = '1';
    let lastStates = updateLastState(topic, state);
    expect(lastStates[topic]).toBe('1');
  });

  it('handles null states', () => {
    const state = null;
    lastStates = updateLastState(topic, state);
    expect(lastStates[topic]).toBeNull();
  });
});
