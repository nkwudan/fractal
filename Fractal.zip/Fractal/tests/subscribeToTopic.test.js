const { subscribeToTopic } = require('../src/helpers');
const mqtt = require('mqtt');
const topics = require('../src/topics.json');
let childTopics = topics.childTopics;
let client;

jest.mock('mqtt', () => {
    const EventEmitter = require('events');
    const originalModule = jest.requireActual('mqtt');
    return {
        ...originalModule,
        connect: () => {
            return new EventEmitter();
        }
    };
});

describe('subscribeToTopic', () => {
    beforeEach(() => {
        client = mqtt.connect();
        client.subscribe = jest.fn();
        console.log = jest.fn(); // Mock console log from main function
    });

    afterEach(() => {
        client.removeAllListeners();  // Clean up listeners after each test
    });
    it('logs error on subscription failure', done => {
        client.subscribe.mockImplementation((topic, callback) => callback(new Error("Failed to subscribe")));

        client.on('connect', () => {
            childTopics.forEach(topic => {
                subscribeToTopic(client, topic);
                let result = expect(console.log).toHaveBeenCalledWith(expect.stringContaining('Failed to subscribe'));
                console.log(`RESULT :: ${result}`)
              });
            done();
        });

        client.emit('connect');
    });
    it('handles successful subscription', done => {
        client.subscribe.mockImplementation((topic, callback) => callback(null));

        client.on('connect', () => {
            childTopics.forEach(topic => {
                subscribeToTopic(client, topic);
                expect(client.subscribe).toHaveBeenCalledWith(topic, expect.any(Function));
              });
            done();
        });
        client.emit('connect');
    });
});
