const { getParentState } = require('../src/helpers');

// UNIT TEST :: Testing decision of parent state based on the child state
describe('getParentState', () => {
  it('returns "denied" if any state is "0"', () => {
    const states = ["1", "1", "0", "1", "1", "1"];
    expect(getParentState(states)).toBe("0");
  });

  it('returns "approved" if all states are "1"', () => {
    const states = ["1", "1", "1", "1", "1", "1"];
    expect(getParentState(states)).toBe("1");
  });

  it('returns the current state if not all are "1" or any are "0"', () => {
    const states = ["1", "1", "1", "1", null, "1"];
    expect(getParentState(states, "1")).toBe("1");
  });
});