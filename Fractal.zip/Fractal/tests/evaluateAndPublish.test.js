const { evaluateAndPublishNewState, updateLastState } = require('../src/helpers');
const topics = require('../src/topics.json');

// UNIT TEST :: Testing to evaluate the current state and make a decision on publishing a new state
// Mock MQTT client
const client = {
  publish: jest.fn()
};

describe('evaluateAndPublishNewState', () => {
  let lastStates = {};
  let parentState = "1"; // the initial approved state
  const parentTopic = topics.parentTopic;

  beforeEach(() => {
    // Reset states and mock functions before each test
    topics.childTopics.forEach(topic => {
      lastStates[topic] = null;
    });
    client.publish.mockClear();
    parentState = "1"; // reset parent state to initial state
  });

  it('publishes new state when a state change is detected', () => {
    // Setup initial state for test
    topics.childTopics.forEach(topic => {
      lastStates = updateLastState(topic, "0"); // simulating all topics denied to force state change
    });
    evaluateAndPublishNewState(client);

    expect(client.publish).toHaveBeenCalledWith(parentTopic, "0");
    expect(client.publish).toHaveBeenCalledTimes(1);
  });

  it('does not publish when no state change is detected', () => {
    let topic = topics.childTopics[0]
    lastStates = updateLastState(topic, "1") // simulating a topic approved, no state change
    evaluateAndPublishNewState(client);

    expect(client.publish).not.toHaveBeenCalled();
  });
});

