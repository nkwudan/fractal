const topics = require('./topics.json');
const childTopics = topics.childTopics;
const parentTopic = topics.parentTopic;
let approved = "1"
let denied = "0"

// Store the last known state of each child topic
const lastStates = {};

// Loop through each topic's last state for a check
childTopics.forEach(topic => {
  lastStates[topic] = null;
});

// Set initial state of the parent
let parentState = approved;

// Connect to mqtt and subscribe to the child topics
function connectAndSubscribe(client) {
  client.on('connect', () => {
    console.log('Connected to MQTT broker');
    childTopics.forEach(topic => {
      subscribeToTopic(client, topic);
    });
  });
}

// Helper to subscribe to a topic
function subscribeToTopic(client, topic) {
  client.subscribe(topic, (err) => {
    if (err) {
      console.log(`Failed to subscribe to ${topic}`);
    } else {
      console.log(`Successfully subscribed to ${topic}`);
    }
  });
}

// Handle updating the message publishing for the child topics and evaluates the parent topic
function handleMessage(client, topic, message) {
  const msgString = message.toString();
  console.log(`Received '${msgString}' from '${topic}'`);

  updateLastState(topic, msgString);
  evaluateAndPublishNewState(client);
}

// Helper for updating the last known state of a child topic
function updateLastState(topic, state) {
  lastStates[topic] = state;
  console.log(`Current states: ${JSON.stringify(lastStates)}`);
  return lastStates
}

// Helper to evaluate changes to the state of the parent topic
function evaluateAndPublishNewState(client) {
  const allStates = Object.values(lastStates);
  const currentParentState = getParentState(allStates);

  console.log("All States:", allStates);
    console.log("Parent State:", currentParentState);

  if (currentParentState !== parentState) {
    parentState = currentParentState;
    client.publish(parentTopic, parentState);
    console.log(`Published ${parentState} to '${parentTopic}'`);
  }
}

// Helper for getting the state of the parent topic
function getParentState(states) {
  if (states.includes(denied)) {
    return denied;
  } else if (states.every(state => state === approved)) {
    return approved;
  }
  return parentState;
}

module.exports = {connectAndSubscribe, subscribeToTopic, evaluateAndPublishNewState, updateLastState, handleMessage, getParentState}