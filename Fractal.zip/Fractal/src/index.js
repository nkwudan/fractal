const mqtt = require('mqtt');
const {connectAndSubscribe, handleMessage} = require('./helpers')

// MQTT Broker settings
const brokerAddress = 'mqtt://localhost'; // Using a local MQTT address
const options = {
  port: 1883,
  log_type: "all",
  allow_anonymous: true
};

const client = mqtt.connect(brokerAddress, options);

client.on('message', (topic, message) => {
  try {
    handleMessage(client, topic, message);
  } catch (error) {
    console.log(`Error processing message: ${error}`);
  }
});

connectAndSubscribe(client);